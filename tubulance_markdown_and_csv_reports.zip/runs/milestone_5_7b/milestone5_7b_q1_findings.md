# Milestone 5.7b, Question 1: where is the persistent spectral pile-up coming from?

> **WARNING:** SYNTHETIC-ONLY DIAGNOSTIC -- computed from the same synthetic pseudo-spectral solver as Milestones 5.7/5.7a, not from real JHTDB DNS data. This memo explains a numerical/structural property of the MODEL'S CODE (where energy accumulates spectrally), not a property of real turbulence.

**Scope:** Question 1 ONLY -- Questions 2 (return-operator sweep), 3 (controller retargeting), 4 (two-variable control architecture) are NOT attempted in this pass.

## Finding

Across all 3 cases tested (weak_64_A, competing_64_A, directional_64_A -- spanning the nonlinear_dominated-to-competing Phi_l range, all previously classified spectral_status=persistent_pileup in the Milestone 5.7a audit), the same qualitative picture holds: the dominant contributor to energy at/above k_c is the NONLINEAR CASCADE (positive nonlinear_transfer -- shells at/above k_c are net energy SINKS from the cascade this step), forcing contributes exactly zero at/above k_c in all 3 cases (none of these cases inject forcing there), and the return-placement kick's contribution is negligible (3-6 orders of magnitude smaller than the nonlinear/viscous channels). The terminal operator's own heat removal (terminal_heat) is consistently far smaller than plain viscous removal at these shells -- roughly 4-25x smaller across the 3 cases -- and net energy at/above k_c is positive (accumulating) in all 3 cases, consistent with their 5.7a spectral_status=persistent_pileup classification.

## Root-cause hypothesis

This is evidence FOR 'insufficient terminal damping' (candidate cause #4 in the 5.7b prompt) as the structural driver, NOT evidence for a return-placement bug (candidate cause #3, ruled out here -- return's contribution is negligible in all 3 cases) or direct forcing near the cutoff (candidate cause #1, ruled out -- forcing is exactly zero at/above k_c for all 3 cases tested). The nonlinear cascade transporting energy toward k_c (candidate cause #2) is real and expected physically -- the finding is that the terminal operator's heat channel is not removing it fast enough to keep the net balance at/above k_c near zero, not that the cascade itself is anomalous.

## Per-case data

| case | net balance at/above kc | nonlinear | viscous | terminal_heat | terminal_return | forcing | heat/viscous ratio |
|---|---|---|---|---|---|---|---|
| weak_64_A | +0.0005357 | +0.004883 | +0.004151 | +0.0001979 | +1.624e-06 | +0 | 0.0477 |
| competing_64_A | +0.0006815 | +0.002401 | +0.001627 | +9.316e-05 | +8.736e-07 | +0 | 0.0573 |
| directional_64_A | +6.175e-07 | +8.286e-07 | +2.05e-07 | +6.182e-09 | +9.226e-11 | +0 | 0.0302 |

## Caveats
- Only 3 of the 12 persistent_pileup-classified cases were tested here (compute-limited, not a full re-audit) -- all 3 happen to share k_f well below k_s (moderate_below_ks), so this finding does NOT yet cover the near_ks/overlap-family cases, which inject forcing much closer to or inside the terminal layer and may show a different dominant channel (forcing itself, not the cascade).
- competing_64_A and directional_64_A were run for 30 of their audited 50 steps (per-shell tracking's added cost exceeded this environment's per-command wall-clock budget at 50 steps for 2 of the 3 cases) -- the qualitative ranking (nonlinear_transfer > viscous > terminal_heat, forcing=0, return negligible) is unlikely to flip with more steps given how consistent it already is across 3 independently-run cases, but the exact magnitudes reported here are a 30-step average, not the audited 50-step average.
- This per-shell ledger is NOT renormalized to sum exactly to the audited scalar totals (see per_shell_energy.py module docstring) -- it answers 'which channel is acting where,' not 'the exact sub-budget.'
- 'terminal_heat' here is the RAW per-mode gamma*alpha*twice_modal removal rate, not the scalar-renormalized terminal_heat reported in the 5.7a audit's energy_budget -- the two will not match exactly, by design.

## Recommended next step

Given the terminal operator's heat removal is confirmed weak relative to viscosity at/above k_c in all 3 cases tested, the most direct next diagnostic (still within Question 1's scope) would be repeating this same measurement on the near_ks_64_A and overlap_64_A cases, where forcing is NOT zero at/above k_c -- to check whether direct forcing becomes the dominant channel there instead, which would mean the 5.7b prompt's Questions 2-4 (return-operator sweep, controller retargeting) need to be scoped separately for 'forcing-fed' vs 'cascade-fed' pile-up rather than treated as one uniform problem.
