# Milestone 5.7 report: Forcing-Material-Size Stress Test

> **WARNING:** SYNTHETIC-ONLY REPORT -- every number below comes from the Milestone 5.7 synthetic pseudo-spectral stress-test solver (pseudo_spectral_solver.py), not from real JHTDB DNS data. This report tests the terminal-layer model's numerical and structural behavior under controlled forcing, material, and size variation. It is evidence about the MODEL'S CODE AND ASSUMPTIONS, not about real turbulence. It must never be cited alongside or in place of the real JHTDB validation campaign (jhtdb_terminal_benchmark.py / run_real_validation.py).

## Strongest permitted statement

> Under the tested synthetic forcing/material/size domain, the original terminal-layer operator's applicability boundary can be mapped: it behaves consistently with its own weak-forcing limit where Phi_l << 1 and forcing is well-separated from k_s, and its assumptions are directly challenged where forcing overlaps or exceeds k_s.

## What is supported
- The forcing/material/size schema (forcing.py, material_state.py, terminal_operator_forcing_aware.py) is implemented and exercised across all 14 preregistered forcing cases without silently approximating an unimplemented material or fabricating a missing resolution tier.
- The first forward-in-time integrator in this repo (pseudo_spectral_solver.py) runs, conserves energy to the tolerance reported per run (unresolved_residual), and its energy-channel attribution (viscous/heat/return split) is exact by construction for the linear part of the timestep -- see module docstring.
- The energy-budget PI controller (controller.py) using the previously-dormant Config.gp=24/gi=8 defaults is now an actual tested control loop, with overshoot/settling-time/oscillation diagnostics reported per run rather than assumed stable.
- Every run is classified with an explicit (forcing case, material, grid_n) domain attached -- no run contributes to a bare supported/not-supported claim without that domain (stress_test_classification.py).

## What is NOT supported
- Any claim about real turbulence: this entire milestone is synthetic-only (see the warning above); it cannot substitute for, and was not run against, real JHTDB data.
- The forcing-aware candidate model (comparison group C, terminal_operator_forcing_aware.gamma_candidate_forcing_aware): it is an explicitly preregistered, UNVALIDATED candidate functional form, not a confirmed improvement over the baseline operator -- see CANDIDATE_KAPPA and IS_CANDIDATE_MODEL in that module.
- Universality of the controller gains: GP=24/GI=8 was tested as a baseline hypothesis (H7), not confirmed as an optimal or universal choice -- see the group-B retuned-gains comparison for how much a calibration-only retune changes stability/overshoot.
- 128^3 resolution results: not executed in this environment (compute-limited); any 128^3 row in this report is status='no_data', never a fabricated result.
- 32^3 resolution results as physical evidence: this tier is diagnostic-only in this milestone's own solver (the beta-derived terminal layer degenerates to ks=0 at this resolution, see milestone_5_7_stress_test.py module docstring) -- consistent with the specification's explicit instruction not to treat 32^3 as physical.

## Unresolved questions
- Whether the candidate forcing-aware gamma correction (group C) actually improves agreement with anything -- there is no real-data ground truth in this milestone to compare it against; it is only compared to the unmodified baseline operator on synthetic data.
- Whether the return-placement kick's shell-random-phase reinjection scheme materially changes structure statistics relative to a different reinjection scheme -- only backscatter_placement.py's four preregistered strategies were exercised, at the shell level, not compared against a modal-level alternative.
- How the applicability map changes at 128^3 and beyond -- not executed here; compute-limited.
- Whether the forcing-amplitude safety clip (pseudo_spectral_solver.make_forcing_hat's lam_max bound) biases the pulsed/impulsive/rotating cases' effective injected power away from their nominal target during the most transient phases -- reported per-run as power_input in the energy budget, but not separately audited against the clip's activation rate in this pass.

## Comparison groups
- **A**: original_fixed_gains -- baseline terminal operator, controller with preregistered fixed gains (GP=24, GI=8)
- **B**: original_retuned_calibration -- baseline operator, controller gains retuned on calibration cases only
- **C**: forcing_aware_candidate -- CANDIDATE gamma modification (terminal_operator_forcing_aware), not validated
- **D**: no_terminal_operator -- terminal operator disabled entirely
- **E**: hard_cutoff -- hard spectral truncation at kc, no smooth damping
- **F**: smooth_damping_no_backscatter -- smooth gamma(k), alpha_s=1.0 (all heat, no return)

## Resolution tiers
- Requested: [32, 64, 128]
- Executed: [32, 64]
- grid_n=128: status=no_data (compute-limited in this environment, not fabricated)

## Runs: 186 total

Runs per comparison group:
- A: 46
- B: 28
- C: 28
- D: 28
- E: 28
- F: 28

## Classification label counts (across all runs; non-exclusive)

| label | count |
|---|---|
| `pipeline_only` | 183 |
| `controller_stable` | 183 |
| `forcing_sensitive` | 183 |
| `anisotropic_response_identified` | 170 |
| `insufficient_resolution` | 98 |
| `terminal_model_requires_extension` | 73 |
| `forcing_overlap_invalidates_assumption` | 12 |
| `terminal_model_not_supported` | 12 |
| `material_interface_only` | 3 |

## Applicability map (D_valid) -- by axis
### By material
- **incompressible_newtonian_liquid**: pipeline_only=169, controller_stable=169, forcing_sensitive=169, anisotropic_response_identified=156, terminal_model_requires_extension=73, insufficient_resolution=84, forcing_overlap_invalidates_assumption=12, terminal_model_not_supported=12
- **generic_compressible_gas_placeholder**: material_interface_only=1
- **high_viscosity_newtonian_liquid**: insufficient_resolution=14, pipeline_only=14, controller_stable=14, forcing_sensitive=14, anisotropic_response_identified=14
- **low_mach_newtonian_gas**: material_interface_only=1
- **simplified_viscoelastic_candidate**: material_interface_only=1

### By Phi_l regime
- **forcing_dominated**: pipeline_only=183, controller_stable=183, forcing_sensitive=183, anisotropic_response_identified=170, terminal_model_requires_extension=73, insufficient_resolution=98, forcing_overlap_invalidates_assumption=12, terminal_model_not_supported=12
- **undefined**: material_interface_only=3

### By Theta_f regime
- **rapid**: pipeline_only=177, controller_stable=177, forcing_sensitive=177, anisotropic_response_identified=164, terminal_model_requires_extension=67, insufficient_resolution=98, forcing_overlap_invalidates_assumption=12, terminal_model_not_supported=12
- **undefined**: material_interface_only=3
- **resonant_or_competing**: pipeline_only=6, controller_stable=6, forcing_sensitive=6, anisotropic_response_identified=6, terminal_model_requires_extension=6

### By k_f vs k_s
- **below**: pipeline_only=67, controller_stable=67, forcing_sensitive=67, anisotropic_response_identified=67, terminal_model_requires_extension=67
- **undefined**: insufficient_resolution=98, pipeline_only=98, controller_stable=98, forcing_sensitive=98, anisotropic_response_identified=97, material_interface_only=3
- **near**: pipeline_only=6, controller_stable=6, forcing_sensitive=6, anisotropic_response_identified=6, terminal_model_requires_extension=6
- **overlap_or_above**: pipeline_only=12, controller_stable=12, forcing_sensitive=12, forcing_overlap_invalidates_assumption=12, terminal_model_not_supported=12

### By grid_n
- **128**: pipeline_only=1, controller_stable=1, forcing_sensitive=1, anisotropic_response_identified=1, terminal_model_requires_extension=1
- **32**: insufficient_resolution=98, pipeline_only=98, controller_stable=98, forcing_sensitive=98, anisotropic_response_identified=97, material_interface_only=3
- **64**: pipeline_only=84, controller_stable=84, forcing_sensitive=84, anisotropic_response_identified=72, terminal_model_requires_extension=72, forcing_overlap_invalidates_assumption=12, terminal_model_not_supported=12
