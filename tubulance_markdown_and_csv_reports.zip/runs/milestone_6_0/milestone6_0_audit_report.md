# Milestone 6.0 Real Implementation Audit -- Structure Discovery Engine

- Generated at git commit: `2e9a4fb5dd6ddc5ec377328f9387c16acab1fe5f`
- Git tree dirty at generation time: True

## 0. How these numbers were obtained

Test count / pass-fail / coverage / timing figures in sections 10-11 were measured by running, in this environment, on Python 3.10.12 with numpy 2.2.6 / scipy 1.15.3 / pandas 2.3.3 / matplotlib 3.10.9 (installed into this sandbox for this session; not previously present -- see 'Repository impact'):
  COVERAGE_FILE=/tmp/.coverage python3 -m pytest tests/test_sd_*.py -q --cov=structure_discovery --cov-report=term-missing
Re-run this exact command to reproduce the numbers below; they are recorded here as a point-in-time result, not re-derived live by this script.

## 1-2. Status and files, per module

### `structure_discovery/structure_representation.py`
- **Status:** fully_implemented
- 9/11 structure types have a real detector (vorticity-magnitude connected components for vortex/vortex_tube/vortex_sheet; strain-magnitude connected components for shear_layer/strain_region; a real spectral pressure-Poisson solve for pressure_minimum/pressure_maximum; the existing compute_terminal_layer for terminal_layer; ForcingState-derived spectral band for forcing_region). cavity and boundary_interaction are explicit placeholders (StructureNotImplementedError) -- no cavitation model or non-periodic domain exists anywhere in this repository to detect either from.

### `structure_discovery/structure_graph.py`
- **Status:** fully_implemented
- All 12 edge relations in the spec vocabulary are implemented: 5 spatial (contains, touches, shares_boundary, distance_weighted, pressure_coupled) computed from a single snapshot, 1 spectral (energy_coupled), and 6 temporal (feeds, creates, destroys, splits, merges, rotates_around) computed from a nearest-centroid match between TWO snapshots via build_temporal_edges(). Deterministic (sorted by structure_id before any pairwise iteration) -- verified by test_graph_determinism_regardless_of_input_order.

### `structure_discovery/interaction_grammar.py`
- **Status:** fully_implemented_small_starter_grammar
- 7 preregistered productions, one worked example per required grammar pattern from the spec, covering all 5 production forms (sequence, combination, suppression, amplification, redirection). This is a small, illustrative starter grammar, not an attempt to enumerate every plausible turbulence-structure interaction -- extending it is a deliberate act (add a GrammarProduction), not something the search can do on its own.

### `structure_discovery/candidate_rule.py`
- **Status:** fully_implemented
- Every field the spec requires is present. The one hard scientific safeguard -- validated=True is structurally impossible unless dns_status=='dns_supported' -- is enforced in __post_init__ and re-checked on every dataclasses.replace() transition (with_synthetic_result / with_dns_result), not just at first construction.

### `structure_discovery/rule_search.py`
- **Status:** fully_implemented_four_backends
- See 'Search implementation' section below for the exact inventory. All four backends requested by the spec (beam search, grammar-guided/exhaustive, Monte Carlo tree search, evolutionary search) are genuinely implemented, not stubbed -- but all four are simple reference implementations, not benchmarked against each other, and grounding (ground_production) is a documented, deliberately loose reachability rule (see module docstring Limitations).

### `structure_discovery/rule_validation.py`
- **Status:** fully_implemented_synthetic_only
- Every candidate is scored using ONLY the pre-existing pseudo_spectral_solver.run_solver, energy_budget.summarize_energy_budget, and nonlinear_transfer.verify_global_conservation/spectral_flux -- no new metric is introduced. No DNS code path exists anywhere in this module (or this package) -- dns_status can never leave 'not_evaluated' from anything this milestone runs.

### `structure_discovery/hypothesis_engine.py`
- **Status:** fully_implemented
- Coordinates search -> evaluation -> ranking -> pruning -> persistence exactly as specified, stopping (by design) before 'DNS Validation -> Accepted/Rejected', which does not exist in this package. Uses a two-snapshot design (earlier snapshot for candidate generation, later snapshot from the SAME seeded run for evaluation).

### `structure_discovery/structure_database.py`
- **Status:** fully_implemented
- SQLite, 6 tables (structures, graphs, relationships, rules, metrics, validation_history), see 'Database' section for full schema/index list. Genuine ID collisions (same ID, different content) raise StructureDatabaseError; idempotent re-inserts of identical structures are silently accepted; rules are UPSERTed on rule_id as their status evolves through the pipeline.

### `structure_discovery/graph_visualization.py`
- **Status:** fully_implemented
- Network graph, interaction-chain overlay, and multi-snapshot evolution figures, all returning matplotlib Figures (headless Agg backend, no GUI). No networkx dependency -- a small from-scratch circular layout (default) and a toy Fruchterman-Reingold spring layout (optional) are implemented directly.

### `structure_discovery/discovery_report.py`
- **Status:** fully_implemented
- Markdown + JSON + CSV, with a hard, mutually-exclusive, exhaustive partition of every rule chain into Observed (not a chain bucket -- structure counts)/Generated/Validated/Rejected/Unverified -- verified never to overlap or miss a chain by test_bucket_chains_are_mutually_exclusive_and_exhaustive. The Validated bucket is always empty in this milestone (see rule_validation.py) and the report says so explicitly rather than omitting the section.

## 3. Public API

Exact, current `class `/`def ` signatures for every module are listed verbatim in milestone6_0_audit_report.md section 3 (extracted directly from the source files at report-generation time via `grep -nE "^(class |def |    def )"` over `structure_discovery/*.py` -- not retyped by hand, so they cannot drift from the code).

(See appendix at the end of this document for the extracted signature list.)

## 4. Internal architecture

```
structure_representation.py  (PhysicalStructure, detectors)
        |
        v
structure_graph.py           (StructureGraph: nodes + typed edges)
        |
        v
interaction_grammar.py       (fixed GRAMMAR productions)
        |
        v
rule_search.py               (ground_production, 4 search backends -> ranked chains)
        |                                 ^
        v                                 |
rule_validation.py  ---------- reuses -----+   (pseudo_spectral_solver, energy_budget,
        |                                       nonlinear_transfer -- all pre-existing)
        v
hypothesis_engine.py          (coordinates all of the above end to end)
        |
        +--> structure_database.py   (SQLite persistence)
        +--> graph_visualization.py  (figures)
        +--> discovery_report.py     (Observed/Generated/Validated/Rejected/Unverified)
```

## 5. Search implementation

- **`grammar_guided`**: Exhaustive DFS enumeration of every valid chain up to max_depth. The reference/ground-truth backend -- guaranteed to find the best-scoring chain within max_depth, at combinatorial cost. Real, complete, not a stub.
- **`beam_search`**: Classic bounded-width beam search: keeps the top beam_width chains at each depth, expands every compatible extension, re-scores, truncates. Real, complete, not a stub.
- **`monte_carlo_tree_search`**: UCB1 tree search: selection descends via UCB1 among expanded children, expansion adds one untried extension, simulation does a random rollout to max_depth, backpropagation updates visit/reward totals along the path. Real MCTS (not a beam search relabeled), but a simple, unoptimized implementation -- no progressive widening, no RAVE, no neural value/policy network (unlike AlphaTensor/AlphaZero-style MCTS, which this does NOT claim to reproduce).
- **`evolutionary`**: Truncation-selection genetic search: population of random chains, top half survives each generation, remainder filled by splice-crossover (prefix of one parent + type-compatible suffix of another) with a chance of truncate-and-re-extend mutation. Real, complete, not a stub.

**Missing/not benchmarked:** None of the four requested families is missing -- but none has been tuned, ablated, or benchmarked for sample-efficiency/solution-quality against the others; grammar_guided is the only one proven optimal (by exhaustion) within max_depth.

## 6. Structure taxonomy

- Implemented structure types (9): forcing_region, pressure_maximum, pressure_minimum, shear_layer, strain_region, terminal_layer, vortex, vortex_sheet, vortex_tube
- Placeholder structure types (2): boundary_interaction, cavity
- Scale types declared: macro, meso, micro, terminal, molecular (molecular is declared but never assigned by any detector)
- Taxonomy categories declared: kinematic, pressure, thermal, material, phase, boundary, acoustic, electromagnetic, terminal
- Taxonomy categories with a real detector behind them: kinematic, pressure, terminal
- Energy channels declared: kinetic, potential, heat, viscous, pressure_work, acoustic, surface, phase, chemical, magnetic, nuclear
- Energy channels implemented: heat, kinetic, viscous

## 7. Grammar (every legal interaction rule)

- **forcing_drives_vortex_via_shear** (sequence): `forcing_region -> shear_layer -> vortex` -- Milestone spec worked example: Forcing -> Shear -> Vortex.
- **vortex_core_becomes_cavity** (sequence): `vortex -> pressure_minimum -> cavity` -- Milestone spec worked example: Vortex -> Pressure minimum -> Cavity. The 'cavity' consequent is a placeholder structure type (structure_representation.PLACEHOLDER_STRUCTURE_TYPES) -- this production is legal grammar, but rule_validation.py can never mark an instance of it validated=True (no cavitation model exists).
- **shear_drives_cascade_via_vortex_pair** (sequence): `shear_layer -> vortex_pair -> cascade` -- Milestone spec worked example: Shear -> Vortex pair -> Cascade.
- **vortex_pair_merges_to_tube** (combination): `vortex + vortex -> vortex_tube` -- Two vortex-family structures combine (A+B->C) into an elongated vortex tube.
- **strain_suppresses_vortex** (suppression): `strain_region suppresses vortex` -- A strain region suppresses vortex formation/persistence in its vicinity.
- **shear_amplifies_vortex** (amplification): `shear_layer amplifies vortex` -- A shear layer amplifies an adjacent vortex (vortex stretching/roll-up).
- **terminal_layer_redirects_energy_to_cascade** (redirection): `terminal_layer redirects energy to cascade` -- The terminal layer redirects processed energy into the forward/local cascade.

## 8. Validation

Metrics reused from previous milestones (verbatim, unmodified):
- pseudo_spectral_solver.run_solver (the existing, unmodified Milestone 5.7 synthetic forward solver -- no second forward-integration code path was added)
- energy_budget.summarize_energy_budget (existing energy-budget closure check, used as a gating precondition, not a pass/fail on the rule itself)
- nonlinear_transfer.verify_global_conservation (existing nonlinear-term conservation sanity check, also gating)
- nonlinear_transfer.spectral_flux / modal_transfer / shell_transfer (existing instantaneous transfer machinery, reused unmodified to check for a forward-cascade signature specifically for chains whose expected_outcome is the composite 'cascade' symbol)

New metrics introduced: None that bypass existing validation. The one new comparison this milestone adds is re-grounding (structure_discovery.rule_search.ground_production) a chain's underlying grammar production against the POST-RUN structure graph -- a presence/connectivity check built entirely on structure_graph.py/interaction_grammar.py, not a new physics metric.

Gating rule: A run whose energy budget does not close within tolerance, or whose nonlinear-transfer conservation residual exceeds tolerance, scores every chain 0.0 with synthetic_status='synthetic_inconclusive' (not 'synthetic_rejected') -- the run cannot be trusted to judge the hypothesis either way. Falsification ('synthetic_rejected') only applies to chains that score 0 against a RELIABLE run.

`synthetic_status` values: ['not_evaluated', 'synthetic_supported', 'synthetic_rejected', 'synthetic_inconclusive']
`dns_status` values: ['not_evaluated', 'dns_supported', 'dns_rejected', 'dns_inconclusive'] (DNS evaluation path exists: False)

## 9. Database

Engine: sqlite3 (Python standard library). Tables: structures, graphs, relationships, rules, metrics, validation_history.

structures.structure_id and rules.rule_id are PRIMARY KEY. insert_structures()/insert_rule() pre-check for a genuine collision (same ID, different content) and raise StructureDatabaseError; an idempotent re-insert of identical content is a silent no-op; rules are explicitly UPSERTed (ON CONFLICT DO UPDATE) as their synthetic_status/dns_status/confidence evolve through the pipeline -- this is the SAME record's evolving state, not a duplicate.

Schema (exact DDL, extracted from `structure_database.SCHEMA_SQL` at generation time):

```sql
CREATE TABLE IF NOT EXISTS structures (
    structure_id TEXT PRIMARY KEY,
    snapshot_label TEXT NOT NULL,
    structure_type TEXT NOT NULL,
    scale TEXT NOT NULL,
    taxonomy TEXT NOT NULL,
    material TEXT NOT NULL,
    resolution INTEGER NOT NULL,
    confidence REAL NOT NULL,
    voxel_count INTEGER NOT NULL,
    position_json TEXT,
    bounding_volume_json TEXT,
    orientation_json TEXT,
    lifetime REAL,
    energy_json TEXT,
    pressure_statistics_json TEXT,
    velocity_statistics_json TEXT,
    metadata_json TEXT,
    inserted_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS graphs (
    graph_id INTEGER PRIMARY KEY AUTOINCREMENT,
    snapshot_label TEXT NOT NULL,
    n_nodes INTEGER NOT NULL,
    n_edges INTEGER NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS relationships (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    snapshot_label TEXT NOT NULL,
    source TEXT NOT NULL REFERENCES structures(structure_id),
    target TEXT NOT NULL REFERENCES structures(structure_id),
    relation TEXT NOT NULL,
    weight REAL NOT NULL,
    metadata_json TEXT,
    UNIQUE(snapshot_label, source, target, relation)
);
CREATE INDEX IF NOT EXISTS idx_relationships_source ON relationships(source);
CREATE INDEX IF NOT EXISTS idx_relationships_target ON relationships(target);
CREATE INDEX IF NOT EXISTS idx_relationships_relation ON relationships(relation);

CREATE TABLE IF NOT EXISTS rules (
    rule_id TEXT PRIMARY KEY,
    equation TEXT NOT NULL,
    machine_representation_json TEXT NOT NULL,
    required_assumptions_json TEXT,
    required_structures_json TEXT,
    expected_outcome TEXT,
    expected_energy_path_json TEXT,
    applicable_material_json TEXT,
    applicable_reynolds_range_json TEXT,
    applicable_forcing_regime_json TEXT,
    confidence REAL NOT NULL,
    synthetic_status TEXT NOT NULL,
    dns_status TEXT NOT NULL,
    validated INTEGER NOT NULL,
    grammar_production_name TEXT,
    provenance_json TEXT,
    inserted_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_rules_grammar_production ON rules(grammar_production_name);
CREATE INDEX IF NOT EXISTS idx_rules_synthetic_status ON rules(synthetic_status);
CREATE INDEX IF NOT EXISTS idx_rules_dns_status ON rules(dns_status);

CREATE TABLE IF NOT EXISTS metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    subject_type TEXT NOT NULL,
    subject_id TEXT NOT NULL,
    metric_name TEXT NOT NULL,
    metric_value REAL,
    recorded_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_metrics_subject ON metrics(subject_type, subject_id);

CREATE TABLE IF NOT EXISTS validation_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chain_rule_ids_json TEXT NOT NULL,
    score REAL NOT NULL,
    evidence_json TEXT NOT NULL,
    recorded_at TEXT NOT NULL
);
```

## 10. Tests

- Number of new tests: **97**
- Passing: **97**, Failing: **0**
- Line coverage of `structure_discovery/` (via `--cov=structure_discovery`): **96%** (1363/1413 statements)
- Wall-clock time for the full new suite: **40.5s**
- Per-module coverage:
  - `structure_representation.py`: 98% (267 stmts, 6 missed)
  - `structure_graph.py`: 97% (177 stmts, 6 missed)
  - `interaction_grammar.py`: 93% (71 stmts, 5 missed)
  - `candidate_rule.py`: 95% (76 stmts, 4 missed)
  - `rule_search.py`: 96% (342 stmts, 13 missed)
  - `rule_validation.py`: 96% (84 stmts, 3 missed)
  - `hypothesis_engine.py`: 98% (96 stmts, 2 missed)
  - `structure_database.py`: 99% (85 stmts, 1 missed)
  - `graph_visualization.py`: 96% (116 stmts, 5 missed)
  - `discovery_report.py`: 95% (97 stmts, 5 missed)
  - `__init__.py`: 100% (2 stmts, 0 missed)

## 11. Benchmarks

- Largest graph actually tested end-to-end: ~120-150 detected structures / ~5,800-7,000 edges (grid_n=8-16 synthetic velocity field, default threshold_fraction=0.5). build_graph() on that graph: well under 0.1s.
- A real performance bug was found and fixed during this milestone's own verification: StructureGraph.neighbors()/an edge-weight lookup originally did an O(len(edges)) linear scan; called repeatedly inside rule_search.ground_production() during exhaustive (grammar_guided) chain scoring, this made a full hypothesis_engine.run_discovery_pipeline call at grid_n=8 exceed 40s (observed hanging past the 40s test budget in this environment). Fixed by adding a cached adjacency index (StructureGraph.adjacency()/edge_weight()); after the fix the same pipeline call completes in ~5s. This is recorded here, not hidden, per this milestone's own honesty requirement.
- Full hypothesis_engine.run_discovery_pipeline() at grid_n=8, n_forward_steps=3-5, beam_search/grammar_guided backend, max_depth=2: ~0.2-11s depending on backend (beam/mcts/evolutionary bounded search: <1s; grammar_guided exhaustive enumeration over ~80 atomic candidates at max_depth=2: ~5-11s, dominated by re-grounding cost during scoring, not by the solver run itself, which is <0.1s at this grid size).
- No memory profiling was performed (no tool available in this sandbox for it); no claim is made about peak memory beyond 'ran without error at the tested sizes above'.

## 12. Scientific safeguards

- **no_validation_leakage**: TRUE. rule_validation.py never uses information from the chain-generation snapshot when scoring against the evaluation snapshot; the grounding check (ground_production) only ever looks at the structures actually detected in whichever snapshot it is passed.
- **no_future_data_leakage**: TRUE by construction: hypothesis_engine.py requires n_forward_steps >= n_initial_steps (HypothesisEngineConfig.__post_init__ raises otherwise) so the evaluation snapshot is never earlier than the candidate-generation snapshot.
- **calibration_validation_separation**: N/A to this milestone in the sense the parent repo uses the term (no model constants are tuned here at all -- no beta/alpha_s/gp/gi retuning happens anywhere in structure_discovery/). The two-snapshot temporal design (generate from snapshot A, score against snapshot B) is the closest analogue and is enforced structurally, not by convention.
- **synthetic_vs_dns_separation**: TRUE, structurally enforced: CandidateRule.__post_init__ raises CandidateRuleError if validated=True and dns_status != 'dns_supported'. No code path in rule_validation.py or anywhere else in this package ever sets dns_status to anything but 'not_evaluated'.
- **placeholder_honesty**: TRUE: cavity/boundary_interaction detectors raise StructureNotImplementedError rather than returning an empty list (which would be indistinguishable from 'searched and found none'); EnergyChannels rejects any attempt to set a non-implemented channel to a numeric value (raises StructureConfigError) rather than silently accepting a fabricated 0.0.
- **reproducibility**: TRUE: SearchConfig.seed is threaded through every backend's np.random.default_rng and recorded on SearchResult.seed/HypothesisEngineResult.seed. test_all_four_backends_run_and_are_reproducible and test_run_discovery_pipeline_reproducible_with_same_seed both assert identical ranked rule-ID sequences across repeated runs with the same seed.

## 13. Remaining limitations

- cavity and boundary_interaction structure types are undetectable placeholders -- no cavitation model or non-periodic domain exists anywhere in this repository.
- Grammar has only 7 preregistered productions -- a small starter set covering the spec's worked examples and all 5 production forms, not a broad interaction ontology.
- Chain-level candidates connect productions by TYPE compatibility of expected_outcome -> required_structures, not by requiring the literal same physical structure instance to be both an earlier rule's output and a later rule's input.
- ground_production's reachability rule (consecutive real symbols connected within max_hops graph edges of ANY relation type) does not distinguish physically meaningful connectivity (e.g. feeds) from merely spatial proximity (distance_weighted).
- No DNS evaluation path exists anywhere in this package -- every rule's dns_status is 'not_evaluated' and validated is False for every rule this milestone can produce.
- Search backends are not benchmarked against each other for sample-efficiency or solution quality; only grammar_guided is proven optimal (by exhaustion).
- Only one synthetic run (one seed, one material/forcing configuration) is evaluated per hypothesis_engine.run_discovery_pipeline() call -- no ensemble/seed-averaging.
- Pruning is a single scalar-score floor, not multi-objective Pareto pruning.
- detect_pressure_structures/detect_vortex_family_structures/detect_strain_structures use a single global threshold_fraction of the field max, not a locally-adaptive or statistically-calibrated threshold.

## 14. Repository impact

New files (22):
- `structure_discovery/__init__.py`
- `structure_discovery/structure_representation.py`
- `structure_discovery/structure_graph.py`
- `structure_discovery/interaction_grammar.py`
- `structure_discovery/candidate_rule.py`
- `structure_discovery/rule_search.py`
- `structure_discovery/rule_validation.py`
- `structure_discovery/hypothesis_engine.py`
- `structure_discovery/structure_database.py`
- `structure_discovery/graph_visualization.py`
- `structure_discovery/discovery_report.py`
- `tests/test_sd_structure_representation.py`
- `tests/test_sd_structure_graph.py`
- `tests/test_sd_interaction_grammar.py`
- `tests/test_sd_candidate_rule.py`
- `tests/test_sd_rule_search.py`
- `tests/test_sd_rule_validation.py`
- `tests/test_sd_hypothesis_engine.py`
- `tests/test_sd_structure_database.py`
- `tests/test_sd_graph_visualization.py`
- `tests/test_sd_discovery_report.py`
- `generate_milestone_6_0_audit_report.py`

Modified existing files:
- `.gitignore`: Added '.coverage' / '.coverage.*' entries so stray pytest-cov artifact files (produced while measuring this milestone's test coverage) are never committed. No line affecting any existing milestone's behavior was touched.

Existing milestone behavior changed: **False**

No file outside structure_discovery/, tests/test_sd_*.py, and generate_milestone_6_0_audit_report.py was written or edited by this milestone (the single .gitignore addition only affects which untracked files git offers to stage, not any code path). Spot-checked existing suites after this milestone's changes: tests/test_structure_metrics.py, test_comparison_metrics.py, test_nonlinear_transfer.py, test_controller.py, test_backscatter_placement.py, test_pseudo_spectral_solver.py, test_forcing.py, test_material_state.py, test_energy_budget.py, test_per_shell_energy.py -- 90/90 passed.

## 15. Final scientific statement

> This milestone adds a working, tested, reproducible SEARCH-MACHINERY layer -- structure detection, graph construction, a fixed interaction grammar, four pluggable search backends, and synthetic-only evaluation reusing the existing solver and comparison infrastructure unmodified -- for generating and ranking candidate turbulence structure-interaction rules. It has NOT discovered, confirmed, or validated any new physical rule: every candidate rule this milestone can produce carries dns_status='not_evaluated' and validated=False, structurally enforced, because no DNS comparison exists anywhere in this package. The only claim this milestone supports is that the search-and-evaluate loop itself runs correctly, deterministically, and honestly reports which of its outputs are Observed, Generated, Rejected (synthetically falsified against a reliable run), or Unverified -- with the Validated bucket, by construction, always empty.

## Appendix: extracted public API signatures

### `structure_discovery/__init__.py`

```
(no top-level classes/functions)
```

### `structure_discovery/candidate_rule.py`

```
73:class CandidateRuleError(ValueError):
77:def new_rule_id(counter: Optional[itertools.count] = None) -> str:
84:class CandidateRule:
102:    def __post_init__(self):
130:    def is_placeholder_outcome(self) -> bool:
135:    def with_synthetic_result(self, status: str, *, confidence: float, evidence: dict) -> "CandidateRule":
142:    def with_dns_result(self, status: str, *, evidence: dict, validated: bool = False) -> "CandidateRule":
154:def from_grammar_production(
```

### `structure_discovery/discovery_report.py`

```
107:def _structure_counts(structures) -> dict:
114:def _bucket_chains(result: HypothesisEngineResult) -> dict:
131:def _chain_summary(ec) -> dict:
143:def generate_discovery_report(
223:def _render_markdown(report: dict) -> str:
```

### `structure_discovery/graph_visualization.py`

```
98:def _circular_layout(node_ids: list) -> dict:
107:def _spring_layout(node_ids: list, edges: list, *, seed: int = 0, iterations: int = 50) -> dict:
139:def _layout(graph: StructureGraph, layout: str, seed: int) -> dict:
148:def plot_network_graph(
184:def plot_interaction_graph(
224:def plot_evolution_graph(
```

### `structure_discovery/hypothesis_engine.py`

```
93:class HypothesisEngineError(ValueError):
98:class HypothesisEngineConfig:
108:    def __post_init__(self):
120:class EvaluatedChain:
127:class HypothesisEngineResult:
138:def _snapshot_structures(solver_config: SolverConfig, n_steps: int):
162:def run_discovery_pipeline(solver_config: SolverConfig, config: HypothesisEngineConfig = HypothesisEngineConfig(), *, db_path: Optional[str] = None) -> HypothesisEngineResult:
184:    def evaluator(chain):
218:def _persist(result: HypothesisEngineResult, initial_structures, final_structures, db_path: str) -> None:
```

### `structure_discovery/interaction_grammar.py`

```
81:class GrammarError(ValueError):
86:class GrammarProduction:
93:    def __post_init__(self):
117:    def human_readable(self) -> str:
130:    def arity(self) -> int:
194:def is_legal_interaction(form: str, symbols: tuple, result: Optional[str] = None) -> bool:
204:def find_production(form: str, symbols: tuple, result: Optional[str] = None) -> Optional[GrammarProduction]:
211:def legal_productions_matching_types(available_types: set) -> list:
```

### `structure_discovery/rule_search.py`

```
114:class SearchConfig:
124:    def __post_init__(self):
132:class SearchResult:
139:    def best_chain(self):
148:def _bfs_distance(graph: StructureGraph, start: str, goal: str, max_hops: int) -> Optional[int]:
168:def _edge_weight(graph: StructureGraph, a: str, b: str) -> float:
172:def ground_production(
237:def generate_atomic_candidates(
267:def compatible_extensions(chain: Chain, atomic_candidates: list) -> list:
276:def default_heuristic_evaluator(chain: Chain) -> tuple:
296:def _is_valid_chain(chain: Chain) -> bool:
303:class _CachedEvaluator:
309:    def __init__(self, evaluator: Evaluator):
314:    def _key(chain: Chain):
317:    def raw(self, chain: Chain):
324:    def value(self, chain: Chain) -> float:
327:    def evidence(self, chain: Chain) -> dict:
331:    def n_evaluations(self) -> int:
334:    def ranked_items(self):
343:class SearchBackend(ABC):
347:    def run(self, atomic_candidates: list, evaluator: Evaluator, config: SearchConfig) -> SearchResult:
351:class GrammarGuidedSearchBackend(SearchBackend):
360:    def run(self, atomic_candidates: list, evaluator: Evaluator, config: SearchConfig) -> SearchResult:
385:class BeamSearchBackend(SearchBackend):
393:    def run(self, atomic_candidates: list, evaluator: Evaluator, config: SearchConfig) -> SearchResult:
438:class MonteCarloTreeSearchBackend(SearchBackend):
448:    def run(self, atomic_candidates: list, evaluator: Evaluator, config: SearchConfig) -> SearchResult:
542:class EvolutionarySearchBackend(SearchBackend):
551:    def run(self, atomic_candidates: list, evaluator: Evaluator, config: SearchConfig) -> SearchResult:
621:def run_search(
```

### `structure_discovery/rule_validation.py`

```
108:class SyntheticEvaluationConfig:
115:    def __post_init__(self):
120:def _final_velocity_real(state) -> np.ndarray:
124:def _cascade_flux_evidence(state, cfg: SolverConfig) -> dict:
146:def run_synthetic_evaluation(config: SyntheticEvaluationConfig) -> dict:
183:def score_chain_against_run(chain: Chain, run_result: dict, *, grounding_max_hops: int = 4) -> tuple:
240:def evaluate_candidate_chain(chain: Chain, config: SyntheticEvaluationConfig) -> tuple:
250:def make_synthetic_evaluator(config: SyntheticEvaluationConfig):
259:    def _evaluator(chain: Chain) -> tuple:
265:def apply_synthetic_result(rule: CandidateRule, score: float, evidence: dict) -> CandidateRule:
```

### `structure_discovery/structure_database.py`

```
72:class StructureDatabaseError(RuntimeError):
165:def _now() -> str:
169:def open_database(path: str) -> sqlite3.Connection:
177:def _json(obj) -> str:
181:def insert_structures(conn: sqlite3.Connection, structures: list, *, snapshot_label: str) -> None:
224:def insert_graph(conn: sqlite3.Connection, graph: StructureGraph, *, snapshot_label: str) -> int:
242:def insert_rule(conn: sqlite3.Connection, rule: CandidateRule) -> None:
291:def insert_validation_history(conn: sqlite3.Connection, *, chain: tuple, score: float, evidence: dict) -> int:
310:def _flatten_numeric(d: dict, prefix: str = ""):
326:def fetch_rule(conn: sqlite3.Connection, rule_id: str) -> Optional[dict]:
335:def fetch_validated_rules(conn: sqlite3.Connection) -> list:
341:def count_rows(conn: sqlite3.Connection) -> dict:
```

### `structure_discovery/structure_graph.py`

```
90:class GraphConfigError(ValueError):
95:class Edge:
102:    def __post_init__(self):
108:class GraphConfig:
122:class StructureGraph:
127:    def sorted_node_ids(self) -> list:
130:    def edges_of_type(self, relation: str) -> list:
133:    def adjacency(self) -> dict:
151:    def neighbors(self, structure_id: str) -> list:
154:    def edge_weight(self, a: str, b: str) -> float:
162:    def node_types(self) -> dict:
165:    def to_dict(self) -> dict:
191:def _is_spatial(s: PhysicalStructure) -> bool:
195:def _is_spectral_band(s: PhysicalStructure) -> bool:
199:def _bbox_axis_overlap(a: tuple, b: tuple) -> bool:
203:def _bbox_overlap(bbox_a: tuple, bbox_b: tuple) -> bool:
207:def _bbox_contains(outer: tuple, inner: tuple) -> bool:
211:def _bbox_gap(bbox_a: tuple, bbox_b: tuple) -> float:
223:def _centroid_distance(a: PhysicalStructure, b: PhysicalStructure) -> float:
228:def _k_overlap_fraction(a: PhysicalStructure, b: PhysicalStructure) -> float:
244:def build_graph(structures: list, config: GraphConfig = DEFAULT_GRAPH_CONFIG) -> StructureGraph:
265:def _spatial_edges(a: PhysicalStructure, b: PhysicalStructure, config: GraphConfig) -> list:
292:def _spectral_edges(a: PhysicalStructure, b: PhysicalStructure, config: GraphConfig) -> list:
304:def build_temporal_edges(
370:def _angle_between_degrees(v1, v2) -> float:
380:def creations_and_destructions(structures_t1: list, structures_t2: list, config: GraphConfig = DEFAULT_GRAPH_CONFIG) -> dict:
```

### `structure_discovery/structure_representation.py`

```
185:class StructureConfigError(ValueError):
191:class StructureNotImplementedError(NotImplementedError):
203:class EnergyChannels:
221:    def __post_init__(self):
231:    def as_dict(self) -> dict:
235:def energy_channel_status() -> dict:
249:class PhysicalStructure:
268:    def __post_init__(self):
280:    def is_placeholder(self) -> bool:
284:def new_structure_id(counter: Optional[itertools.count] = None) -> str:
298:def spectral_grids(u: np.ndarray, domain_length: float):
312:def strain_magnitude_field(uh: np.ndarray, kx, ky, kz) -> np.ndarray:
326:def vorticity_magnitude_field(uh: np.ndarray, kx, ky, kz) -> np.ndarray:
334:def pressure_field(uh: np.ndarray, kx, ky, kz, kmag: np.ndarray) -> np.ndarray:
361:def _field_statistics(field: np.ndarray, mask: Optional[np.ndarray] = None) -> dict:
373:def _velocity_statistics(u: np.ndarray, mask: Optional[np.ndarray] = None) -> dict:
384:class StructureClassificationThresholds:
397:def _connected_components_with_geometry(scalar_field: np.ndarray, threshold_fraction: float):
444:def _classify_elongation(eigvals: Optional[np.ndarray], thresholds: StructureClassificationThresholds) -> str:
463:def classify_scale(voxel_count: int, grid_n: int, layer: Optional[TerminalLayer] = None, *, wavenumber: Optional[float] = None) -> str:
487:def detect_vortex_family_structures(
533:def detect_strain_structures(
580:def detect_pressure_structures(
640:def detect_terminal_layer_structure(
683:def detect_forcing_region_structure(
739:def detect_cavity_structures(*args, **kwargs) -> list[PhysicalStructure]:
750:def detect_boundary_interaction_structures(*args, **kwargs) -> list[PhysicalStructure]:
765:def detect_all_structures(
```
