# navier3d

A modular, general-purpose three-dimensional incompressible Navier-Stokes
solver in Python, developed incrementally with an explicit verification
hierarchy. See [`docs/architecture.md`](docs/architecture.md) for the full
design (grid arrangement, array shapes, boundary-condition formulas,
planned projection algorithm).

## Status: Milestone 9

Package skeleton, validated configuration system, structured MAC-grid
mesh, staggered field containers, boundary-condition interfaces,
compatible discrete spatial operators, a sparse pressure Poisson system,
velocity projection, and a full unsteady solver for the **complete
incompressible Navier-Stokes equations** (`convection.py`: conservative
MAC-grid nonlinear convection, centered and upwind schemes;
`time_integrators.py`: AB2 explicit convection + Crank-Nicolson implicit
diffusion + projection). Verified against the Taylor-Green vortex (an
exact solution of the full nonlinear equations), a manufactured full
Navier-Stokes solution, near-inviscid energy behavior, and long
nonlinear runs. **No turbulence model, LES, adaptive mesh refinement,
compressibility, or complex geometry exist yet.** Nothing in this
package should be treated as DNS, LES, or a validated turbulence
solution merely because it runs without diverging -- see
`docs/architecture.md` Section 7 for the current limitations and explicit
scientific-scope restrictions.

**Milestone 9** (see `docs/architecture.md` Section 16): a focused
follow-up investigation into Milestone 8's open question, using a
from-scratch (SymPy-derived, numerically self-checked) manufactured
unsteady Stokes wall problem and staged isolation (CN diffusion alone
-> add the pressure predictor term -> add full projection). **Root
cause found and fixed at the isolated-predictor level**: the
incremental/rotational predictor used `p^n` (the previous step's
pressure, evaluated at `t^n`) directly, which is only first-order
accurate for a theta=0.5 (Crank-Nicolson) scheme -- capping order at 1
regardless of how good the projection step is. A `theta`-parametrized
linear extrapolation to the correct evaluation time (`p_extrap =
(1+theta*r)*p^n - theta*r*p^{n-1}`, the same technique already used for
AB2's convection term, `pressure_extrapolation=True`, opt-in) recovers
clean order 2.00 in the isolated predictor test, confirmed stable to
the roundoff floor. Through the full pipeline, this cleanly reaches
order 2 starting from a state consistent with an exact solution, but
Milestone 8's own "arbitrary initial condition" test methodology still
shows order ~1 regardless of the fix -- traced to a **startup-transient
effect** (an inconsistent `p^0=0` combined with a non-flow-consistent
velocity IC), not a persistent steady-state defect, via a settling
experiment -- reported honestly as the milestone's own next open
question, not claimed fully resolved. The wall-boundary row treatment
itself was proven (not assumed) to carry zero temporal truncation error
of its own, ruling it out as a cause.

**Milestone 8** (see `docs/architecture.md` Section 15): selectable
pressure-correction projection methods --
`projection_method="non_incremental"` (default, unchanged Chorin
method), `"incremental"`, and `"rotational"` (`chi=` configurable) --
with a pressure history now carried in `FlowState.pressure` across
steps, and a from-scratch derivation of the pressure-increment (`phi`)
boundary conditions distinguishing them from the full pressure's own
(most notably: `phi`'s Dirichlet value at a `pressure_outlet` face must
be `0`, not the outlet's configured `pressure_value`, or the update
`p^{n+1}=p^n+phi` would double it). Measured on a wall-bounded case (the
only kind that can distinguish the methods -- periodic domains provably
cannot, see the architecture doc): incremental/rotational reduce
temporal error **magnitude** by ~2x for both velocity and pressure, but
-- reported honestly rather than hidden -- **none of the three methods
reaches order-2 temporal convergence** in this solver's specific
fully-implicit-diffusion discretization; a systematic root-cause
investigation rules out projection splitting, AB2/CN coupling, and the
spatial error floor, pointing instead to the near-wall pressure BC
treatment interacting with the fully-implicit diffusion predictor. Also
closes Milestone 7's unbounded-cache issue (now a bounded LRU,
`diffusion_cache_max_size=8` default).

**Milestone 7** (see `docs/architecture.md` Section 14): a shared
direct/iterative (CG/BiCGSTAB/GMRES, optional PyAMG) linear-solver
backend (`linear_solvers.py`) used by both `pressure.py` and
`diffusion.py`; a new symmetric-positive-definite diffusion formulation
(`diffusion.py`, opt-in via `formulation="spd"`) enabling CG where the
original pin-row formulation only permitted a direct solve; matrix/
preconditioner reuse and warm starts; CFL-driven adaptive timestepping
with a correctly-derived variable-step AB2 (`adaptive.py`); explicit
profiling (`profiling.py`) and memory accounting (`memory.py`). Measured
(not assumed): iterative is 63-170x faster per step than direct even
amortized over repeated solves, and direct-LU's fill-in becomes
prohibitive (~1.2 GB per matrix, measured, at a 32^3 grid) well before
iterative does. All Milestone 1-6 behavior and tests are unchanged --
direct/pinned remains the library default; the faster paths are opt-in.
The Milestone 6 correction's `O(dt)` projection-splitting ceiling
(above) was deliberately **not** touched in this milestone.

**Milestone 6 correction round** (see `docs/architecture.md` Section
13): a documentation sign typo in the AB2/CN predictor formula was found
and fixed (the code itself was already correct; an independent,
projection-free predictor-level sign test was added,
`tests/test_predictor_sign.py`), and the AB2 convection startup was
upgraded from 1st-order (forward Euler) to 2nd-order (Heun's method).
The overall scheme's temporal order is nonetheless still measured at
~1.0-1.3, not the requested ~2, because `projection.py`'s
non-incremental (Chorin-type) pressure projection has its own intrinsic
`O(dt)` splitting error, independent of the predictor's accuracy --
reaching true second-order overall accuracy would require upgrading the
projection algorithm itself (an incremental/rotational pressure
correction), a larger architectural change flagged to the reviewer
rather than attempted unilaterally.

## Environment setup

```bash
python -m venv .venv
```

Activate it (shell-specific -- pick the one matching your terminal):

```powershell
# PowerShell
.venv\Scripts\Activate.ps1
```

```cmd
:: Command Prompt
.venv\Scripts\activate.bat
```

```bash
# Git Bash / WSL / macOS / Linux
source .venv/Scripts/activate      # Git Bash on Windows
source .venv/bin/activate          # WSL / macOS / Linux
```

Then install:

```bash
pip install -e ".[dev]"
```

## Running tests

```bash
pytest
```

## Repository layout

```
navier3d/
├── src/navier3d/          # package source
│   ├── _indexing.py         # shared low-level padded-array indexing helpers
│   ├── config.py           # validated dataclass configuration + YAML loading
│   ├── mesh.py              # structured Cartesian mesh geometry
│   ├── fields.py            # ghost-padded MAC-grid field containers + named accessors
│   ├── boundary_conditions.py  # BC specification + ghost-cell enforcement
│   ├── operators.py          # gradient, divergence, scalar/velocity Laplacian
│   ├── pressure.py            # sparse pressure Poisson system: assembly, null-space, solvers
│   ├── projection.py          # velocity projection: non-incremental/incremental/rotational
│   ├── diffusion.py            # reusable implicit velocity-diffusion systems (theta-scheme, SPD option)
│   ├── convection.py            # conservative MAC-grid nonlinear convection: centered/upwind
│   ├── time_integrators.py      # AB2 convection + theta-scheme diffusion + projection, adaptive dt
│   ├── linear_solvers.py         # shared direct/CG/BiCGSTAB/GMRES + Jacobi/AMG backend
│   ├── adaptive.py                # CFL-driven adaptive dt controller + variable-step AB2
│   ├── profiling.py                # explicit per-category step timers
│   └── memory.py                    # field/matrix/solver memory accounting
├── tests/                  # pytest unit tests
├── docs/architecture.md    # design document
├── examples/                # (added starting Milestone 9+)
└── benchmarks/               # scaling_benchmark.py (Milestone 7)
```

Modules not yet present (`solver.py`, `diagnostics.py`, `io.py`,
`visualization.py`) are added incrementally starting Milestone 9, each
with working code and tests -- not as empty placeholders.

## Optional extras

```bash
pip install -e ".[amg]"    # PyAMG-preconditioned pressure solves
pip install -e ".[perf]"   # psutil-based real process-memory measurement
```

Both are fully optional -- the package works completely without them;
the tests that need them are skipped automatically when absent.

## Development roadmap

Milestones 1-10+ are tracked as described in the project's development
plan: differential operators and verification (M2), pressure Poisson
solver with null-space handling (M3), projection / divergence removal
(M4), unsteady Stokes flow (M5), nonlinear convection and Taylor-Green
vortex (M6), performance/adaptive time stepping (M7), second-order
pressure-correction projection (M8), I/O and diagnostics (M9),
lid-driven cavity (M10+), LES infrastructure (later). Each milestone
must pass its tests before the next begins.
